const mongoose = require('mongoose');
const Schema  = mongoose.Schema;

const MovieSchema = new Schema({
	searchText: Schema.Types.ObjectId,
    title: {
			type: String,
	
    },
    Year: {
    	type: Number,
			
		},
    imdbId: {
			type: String,
			
		},
    Type: {
    	type: String,
			
		},
    Poster: {
    	type: String,
			
		}
});

module.exports = mongoose.model('movie', MovieSchema);



