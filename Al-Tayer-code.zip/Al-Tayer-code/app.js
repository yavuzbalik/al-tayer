const request = require("request");
const url = require('url');
const express = require('express');
var cors = require('cors');
const app = express();
const bodyParser = require('body-parser');

const NodeCache = require( "node-cache" );
const myCache = new NodeCache();
app.use(cors());

"use strict";
app.use(bodyParser.json({}));       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({
    
extended: true                      // to support URL-encoded bodies
}));
const basePath='http://www.omdbapi.com/?apikey=c665692b&s='



app.get('/api/search', (req, res,next) => {
  
  
        
        var query = url.parse(req.url,true).query;
        var key=query.keyword
        console.log(key)
       var tryCache=myCache.get(key)
        
        if(tryCache!==undefined){
          
          res.send({Search:tryCache,Response:'True'})
        }
else{
      async function sendMovie() {
        try{
          
        const list1 = await getMovies(key,1);
        const list2 = await getMovies(key,2);
        
      var result = list1.concat(list2)
        
        
        myCache.set( key, result, 30000 );

        res.send({Search:result,Response:'True'})
        }
        catch (e){
          console.log(e)
          res.send({status:400,result:e})
        }
      }
      
      sendMovie();
    }
    
  });


  app.get('/api/clear',(req,res)=>{
    
   
    myCache.flushAll()
      
    
    res.send({status:200,message:"cache erased"})

  })



  function getMovies(key,page) {
  return new Promise((resolve,reject) => {
    if(key.length>2){
    var reqURL=basePath+key+'&'+'page='+page+'';


    request.get(reqURL, function(err, resp, body) {
    if (err) {
      console.log(err)
        reject(err);
    } else {
        try {
        var parsed = JSON.parse(body);
        
        if(parsed["Response"]==="True"){
         
         
          resolve(parsed['Search']);
          }
          
          else
            reject(parsed["Error"]);
            
    }   catch (e) {
          reject(e)
    }
  }
})
}   

    else
      reject ("string length must be greater than 2 ")
    });
}

  

  


app.listen(8080, () => console.log('Server running on port 8080'))