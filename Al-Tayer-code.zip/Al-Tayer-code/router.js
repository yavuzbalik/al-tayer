const express = require('express');
const router = express.Router();
const movies=require('./movies')
const NodeCache = require( "node-cache" );
const myCache = new NodeCache();
const url = require('url');




router.get('/api/search', (req, res) => {
	

    var query = url.parse(req.url,true).query;
        var key=query.keyword
       var tryCache=myCache.get(key)
        
        if(tryCache!==undefined){
          
          res.send({Search:tryCache,Response:'True'})
        }
else{
      async function sendMovie() {
        try{
        const list1 = await movies.getMovies(key,1);
        const list2 = await movies.getMovies(key,2);
        
      var result = list1.concat(list2)
        
        
        myCache.set( key, result, 30000 );

        res.send({Search:result,Response:'True'})
        }
        catch (e){
          res.send({status:400,result:e})
        }
      }
      
      sendMovie();
    }

    
});


router.get('/api/clear',(req,res)=>{
    
   
    myCache.flushAll()
      
    
    res.send({status:200,message:"cache erased"})

  })


module.exports = router;