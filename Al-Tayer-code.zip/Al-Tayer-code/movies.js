const request = require("request");
const basePath='http://www.omdbapi.com/?apikey=c665692b&s='


module.exports=function getMovies(key,page) {
  return new Promise((resolve,reject) => {
    if(key.length>2){
    var reqURL=basePath+key+'&'+'page='+page+'';
console.log('get movies')

    request.get(reqURL, function(err, resp, body) {
    if (err) {
      console.log(err)
        reject(err);
    } else {
        try {
        var parsed = JSON.parse(body);
        
        if(parsed["Response"]==="True"){
         console.log(parsed["Search"])
          resolve(parsed["Search"]);
          }
          
          else
            reject(parsed["Error"]);
            
    }   catch (e) {
          reject(e)
    }
  }
})
}   

    else
      reject ("string length must be greater than 2 ")
    });
}